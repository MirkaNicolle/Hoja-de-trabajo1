import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ JUnitApagarEncender.class, JUnitCambioEstaciones.class, JUnitCambioTipoFrecuencias.class })
public class JUnits {

}
